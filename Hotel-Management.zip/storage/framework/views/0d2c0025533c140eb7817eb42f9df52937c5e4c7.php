<?php $__env->startSection('content'); ?>
   <h1 style="text-align:center">Home Page</h1> 
   
   <div class="container-fluid">
      <div class="container">
         <div class="col-md-6">

         </div>
         <div class="col-md-6">
            
         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8\htdocs\laravel_tut\Hotel-Management\resources\views/home.blade.php ENDPATH**/ ?>