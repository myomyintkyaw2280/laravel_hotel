@extends('layout')

@section('content')
   <h1 style="text-align:center">Home Page</h1> 
   
   <div class="container-fluid">
      <div class="container">
         <div class="col-md-6">

         </div>
         <div class="col-md-6">
            
         </div>
      </div>
   </div>
@endsection